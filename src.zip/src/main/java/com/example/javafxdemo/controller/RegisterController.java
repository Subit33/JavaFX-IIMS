package com.example.javafxdemo.controller;

public class RegisterController {
}
